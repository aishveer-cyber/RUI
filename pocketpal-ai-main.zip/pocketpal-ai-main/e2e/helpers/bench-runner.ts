/**
 * Spec-side helpers for benchmark-matrix (BenchmarkRunnerScreen-driven).
 *
 * The screen owns the matrix loop and JSON write; this module supplies the
 * config-builder, deep-link launcher, report puller, and per-row logcat
 * slicer. Kept here (not inlined in the spec) so the spec body stays under
 * the LOC target.
 */

import * as fs from 'fs';
import * as os from 'os';
import * as path from 'path';
import {execFileSync, execSync} from 'child_process';

import {getBenchmarkMatrix} from '../fixtures/benchmark-models';

// `driver` is the global injected by WebdriverIO when the spec runs. The
// WebdriverIO types live only in e2e/node_modules, so the root tsc program
// cannot resolve them when the unit-test suites under scripts/__tests__/
// import this module for the shared `buildConfig` export. Typed loosely so
// both programs compile; the spec gets the strongly-typed `driver` from
// WebdriverIO's own globals at runtime.
declare const driver: any;

export const PACKAGE = 'com.pocketpalai.e2e';
export const REMOTE_DIR = `/sdcard/Android/data/${PACKAGE}/files`;

// argv-style adb invocation. The udid flows in from process.env (E2E_DEVICE_UDID)
// — passing it as its own argv slot ([-s, udid]) makes shell-metacharacter
// injection structurally impossible. Replaces the previous shell-string
// `execSync(\`adb ${...}\`)` call shape (round-1 C4).
export const adb = (udid: string | undefined, ...args: string[]): string => {
  const argv = udid ? ['-s', udid, ...args] : args;
  return execFileSync('adb', argv, {
    encoding: 'utf8',
    timeout: 60_000,
  }).trim();
};

export function buildConfig(matrix: ReturnType<typeof getBenchmarkMatrix>) {
  const base = {
    models: matrix.models.map(m => ({
      id: m.id,
      hfModelId: `${m.searchQuery.trim().split(/\s+/)[0]}/${m.selectorText}-GGUF`,
      quants: matrix.quants
        .map(q => m.quants?.find(v => v.quant === q))
        .filter((v): v is NonNullable<typeof v> => Boolean(v))
        .map(v => ({quant: v.quant, filename: v.downloadFile})),
    })),
    backends: matrix.backends,
    bench: {pp: 512, tg: 128, pl: 1, nr: 3},
  };
  // WHAT 9a: empty settings_axes MUST be omitted (not emitted as []).
  // Producers (CLI / spec helper) keep the wire format canonical so the
  // screen has exactly one absence-shape to handle.
  if (matrix.settings_axes && matrix.settings_axes.length > 0) {
    return {...base, settings_axes: matrix.settings_axes};
  }
  return base;
}

/** Mirrors `runMatrix`'s cell loop: model quants × backends × axis values. */
export function expectedCellCount(cfg: {
  models: Array<{quants: unknown[]}>;
  backends: unknown[];
  settings_axes?: Array<{values: unknown[]}>;
}): number {
  const quantCount = cfg.models.reduce((sum, m) => sum + m.quants.length, 0);
  const axesProduct = (cfg.settings_axes ?? []).reduce(
    (acc, a) => acc * a.values.length,
    1,
  );
  return quantCount * cfg.backends.length * axesProduct;
}

export interface BenchReportRow {
  model_id: string;
  quant: string;
  requested_backend: string;
  status: string;
  error?: string;
  reason?: string;
}

export interface BenchReportFile {
  runs: BenchReportRow[];
  outcome?: string;
  device?: string;
  soc?: string | null;
  os_version?: string;
  commit?: string;
  llama_rn_version?: string;
}

/** Fills the top-level fields the on-device runner cannot know. */
export function stampReportMetadata(
  report: BenchReportFile,
  meta: {device: string; osVersion: string},
): void {
  report.device = meta.device;
  report.soc = process.env.E2E_DEVICE_SOC || null;
  report.os_version = meta.osVersion;
  report.commit = getCommitHash();
  report.llama_rn_version = getLlamaRnVersion();
}

/** A matrix whose every cell failed still ends `complete`, so the rows are
 * the pass gate. */
export function assertRowsPass(report: BenchReportFile): void {
  if (!report.runs.length) {
    throw new Error('Matrix produced zero rows');
  }
  const failed = report.runs.filter(r => r.status !== 'ok');
  if (failed.length > 0) {
    const summary = failed
      .map(
        r =>
          `${r.model_id}::${r.quant}::${r.requested_backend}: ` +
          String(r.error ?? r.reason ?? 'unknown').slice(0, 120),
      )
      .join('; ');
    throw new Error(
      `Matrix completed but ${failed.length}/${report.runs.length} cells failed: ${summary}`,
    );
  }
}

export function pushConfig(
  matrix: ReturnType<typeof getBenchmarkMatrix>,
  udid?: string,
): string {
  const cfgFile = path.join(os.tmpdir(), 'pocketpal-bench-config.json');
  fs.writeFileSync(cfgFile, JSON.stringify(buildConfig(matrix), null, 2));
  adb(udid, 'shell', 'mkdir', '-p', REMOTE_DIR);
  adb(udid, 'push', cfgFile, `${REMOTE_DIR}/bench-config.json`);
  return cfgFile;
}

export async function deepLinkLaunch(): Promise<void> {
  // `?autostart=1` makes the runner screen self-start its matrix run with no
  // injected tap. This is the fix for HyperOS / MediaTek devices, where the
  // OS silently drops `adb shell input tap` (and WDIO's analogous .click()),
  // so a tap-driven start never fired onPress. The screen now invokes the
  // exact same start handler the button does.
  await driver.execute('mobile: deepLink', {
    url: 'pocketpal://e2e/benchmark?autostart=1',
    package: PACKAGE,
  });
}

export function pullLatestReport(outDir: string, udid?: string): string {
  // `adb shell ls <pattern>` works with argv (no shell expansion needed —
  // the device-side shell expands the glob). Each token is its own argv
  // slot so neither REMOTE_DIR nor the udid can carry shell metacharacters
  // into the host shell.
  const remote = adb(udid, 'shell', 'ls', `${REMOTE_DIR}/benchmark-report-*.json`)
    .split('\n')
    .filter(Boolean)
    .sort()
    .slice(-1)[0];
  if (!remote) {
    throw new Error('No benchmark-report-*.json on device');
  }
  const localFile = path.join(outDir, path.basename(remote));
  adb(udid, 'pull', remote, localFile);
  return localFile;
}

export function getCommitHash(): string {
  try {
    return execSync('git rev-parse --short HEAD', {
      encoding: 'utf8',
      timeout: 5000,
    }).trim();
  } catch {
    return 'unknown';
  }
}

export function getLlamaRnVersion(): string {
  try {
    const pkg = JSON.parse(
      fs.readFileSync(
        path.resolve(__dirname, '..', '..', 'package.json'),
        'utf8',
      ),
    );
    return (
      pkg.dependencies?.['llama.rn'] ||
      pkg.devDependencies?.['llama.rn'] ||
      'unknown'
    );
  } catch {
    return 'unknown';
  }
}
