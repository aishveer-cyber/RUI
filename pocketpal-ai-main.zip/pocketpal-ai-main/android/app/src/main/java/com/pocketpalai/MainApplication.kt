package com.pocketpal

import android.app.Application
import android.system.Os
import com.facebook.react.PackageList
import com.facebook.react.ReactApplication
import com.facebook.react.ReactHost
import com.facebook.react.ReactNativeHost
import com.facebook.react.ReactPackage
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint.load
import com.facebook.react.defaults.DefaultReactHost.getDefaultReactHost
import com.facebook.react.defaults.DefaultReactNativeHost
import com.facebook.react.soloader.OpenSourceMergedSoMapping
import com.facebook.soloader.SoLoader
import com.pocketpal.KeepAwakePackage
import com.pocketpal.HardwareInfoPackage
import com.pocketpal.NavigationBarPackage
import com.pocketpal.download.DownloadPackage

class MainApplication : Application(), ReactApplication {

  override val reactNativeHost: ReactNativeHost =
      object : DefaultReactNativeHost(this@MainApplication) {
        override fun getPackages(): List<ReactPackage> =
            PackageList(this).packages.apply {
              // Packages that cannot be autolinked yet can be added manually here, for example:
              // add(MyReactNativePackage())
              add(KeepAwakePackage())
              add(HardwareInfoPackage())
              add(DownloadPackage())
              add(NavigationBarPackage())
            }

        override fun getJSMainModuleName(): String = "index"

        // Independent of BuildConfig.DEBUG: releaseE2e is `debuggable=true`
        // for `adb run-as` but must still load the baked bundle, not from
        // a locally-running Metro server.
        override fun getUseDeveloperSupport(): Boolean = BuildConfig.USE_DEV_SUPPORT

        override val isNewArchEnabled: Boolean = BuildConfig.IS_NEW_ARCHITECTURE_ENABLED
        override val isHermesEnabled: Boolean = BuildConfig.IS_HERMES_ENABLED
      }

  override val reactHost: ReactHost
    get() = getDefaultReactHost(applicationContext, reactNativeHost)

  override fun onCreate() {
    super.onCreate()
    // Enable Adreno large buffer support on Qualcomm A7X/A8X GPUs.
    // The OpenCL backend in llama.rn self-gates on GPU family and the
    // cl_qcom_large_buffer extension — this is a no-op on non-Adreno devices.
    // Must be set before SoLoader.init so the native library picks it up.
    // See: https://github.com/ggml-org/llama.cpp/pull/20997
    Os.setenv("GGML_OPENCL_ADRENO_USE_LARGE_BUFFER", "1", true)
    SoLoader.init(this, OpenSourceMergedSoMapping)
    if (BuildConfig.IS_NEW_ARCHITECTURE_ENABLED) {
      // If you opted-in for the New Architecture, we load the native entry point for this app.
      load()
    }
  }
}
